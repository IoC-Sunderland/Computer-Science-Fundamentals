import time
from random import randrange
# An example of O(1) or "Constant" time is appending to a list
myList = []
myList.append(100)
print (myList)

# An example of a O(1) or "Constant" time function below:
# Example: aList = [4,7,2]
def constantTimeFunction(aList):
    x = 0
    return x


