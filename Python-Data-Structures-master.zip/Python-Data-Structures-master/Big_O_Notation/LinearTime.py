import time
from random import randrange

def total(aList):
    x = 0
    for item in aList:
        x += item
    return x

while True:
    RandomListOfIntegers = [randrange(9, 99) for iter in range(10000000)]
    start_time = time.time()
    total(RandomListOfIntegers)
    end_time = time.time()
    print("Size: {} Time: {}".format(len(RandomListOfIntegers), end_time - start_time))
    time.sleep(3)


