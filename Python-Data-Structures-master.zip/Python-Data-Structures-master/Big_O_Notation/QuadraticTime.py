# Example: array_2d = [[4,7],[1,1]]
def total(array_2d):
    x = 0
    for row in array_2d:
        for item in row:
            x += item
    
    return x

