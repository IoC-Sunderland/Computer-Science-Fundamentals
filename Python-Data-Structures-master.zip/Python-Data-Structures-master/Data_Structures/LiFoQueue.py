from Queue import LifoQueue

# Create an empty LifoQueue (Last In First Out Queue)
myStack = LifoQueue()

# Note: you know 'put' items rather than 'append' items
myStack.put('a')
myStack.put('b')
myStack.put('c')

print(myStack)

# Note: you know 'get' items rather than 'pop' items
print(myStack.get())

print(myStack.get())

print(myStack.get())

myStack.get_nowait()
