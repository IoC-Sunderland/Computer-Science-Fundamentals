from collections import deque

# Create an empty deque (double ended queue)
myStack = deque()

myStack.append('a')
myStack.append('b')
myStack.append('c')

myStack
deque(['a', 'b', 'c'])


print("\n")
print("*****Example 2: Using a deque to create a Python stack*****\n")
print("Current contents of deque: \n")
print(myStack)
print("\n")

# Call the .pop() method to remove the last item
print("Now we remove or 'pop' the following item: " + myStack.pop())
print("\n")

# And again
print("Now we remove or 'pop' the following item: " + myStack.pop())
print("\n")

#And again
print("Now we remove or 'pop' the following item: " + myStack.pop())
print("\n")

# Try calling .pop() when deque is empty
try:
    myStack.pop()
except IndexError as e:
    print("Error when calling .pop().\n\nAssociated error message: " + str(e))

print("\n")
print("*****End of example*****\n")
