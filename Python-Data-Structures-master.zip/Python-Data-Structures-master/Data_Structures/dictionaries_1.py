# Create a dictionary named Capitals
Capitals = {
    'United Kingdom' : 'London',
    'Ethiopia'   : 'Addis Ababa',
    'Madagascar': 'Antananarivo',
    'Republic of the Congo': 'Brazzaville',
    'Palau'  : 'Ngerulmud'
 }

print("\n")
print("*****Example 4: Python dictionaries*****\n")
print("Current contents of 'Capitals' dictionary: \n")
print(Capitals)
print("\n")

# You can't access by index
try:
    print(Capitals[1])
except KeyError as e:
    print("Error when accessing by index.\n\nAssociated error message: " + str(e))

print("\n")

# Add a new entry
Capitals['Paris'] = 'France'

print("\n")
print(Capitals)

# Update an entry
Capitals['United Kingdom'] = 'Sunderland'

print("\n")
print(Capitals)

# Delete an entry
del Capitals['United Kingdom']

print("\n")
print(Capitals)
print("\n")

try:
    print(Capitals['United Kingdom'])
except KeyError as e:
    print("Error when accessing non-existant key.\n \
        \nAssociated error message: " + str(e))

print("\n")
print("*****End of example*****\n")

'''
Note: Although access to items in a dictionary does not depend on order,
Python does guarantee that the order of items in a dictionary is preserved.
When displayed, items will appear in the order they were defined,
and iteration through the keys will occur in that order as well.
Items added to a dictionary are added at the end.
If items are deleted, the order of the remaining items is retained.
'''