# Create an empty dictionary
us_presidents = {}


us_presidents['first_name'] = 'George'
us_presidents['last_name'] = 'Washington'
us_presidents['birthplace'] = "Westmoreland County, Virginia"
us_presidents['spouse'] = 'Martha Washington'
us_presidents['vice_president'] = 'John Adams'
us_presidents['cabinet'] = ['Thomas Jefferson - Secretary of State',
                            'Alexander Hamilton - Secretary of the Treasury']
 
print("\n")
print("*****Example 5: Python dictionaries*****\n")
print("Current contents of 'us_presidents' dictionary: \n")
print(us_presidents)
print("\n")

# Print individual values
print(us_presidents['first_name'])
print(us_presidents['last_name'])
print(us_presidents['birthplace'])
print(us_presidents['spouse'])
print(us_presidents['vice_president'])
print(us_presidents['cabinet'])

# Accessing the sub-list
print(us_presidents['cabinet'][0])
print(us_presidents['cabinet'][1])

print("\n")
print("*****End of example*****\n")
