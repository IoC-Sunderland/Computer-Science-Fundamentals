# Other stuff with dictionaries
Capitals = {
    'United Kingdom' : 'London',
    'Ethiopia'   : 'Addis Ababa',
    'Madagascar': 'Antananarivo',
    'Republic of the Congo': 'Brazzaville',
    'Palau'  : 'Ngerulmud'
 }

print("\n")
print("*****Example 6: Other stuff with dictionaries*****\n")
print("Current contents of 'Capitals' dictionary: \n")
print(Capitals)
print("\n")

# Is 'London' in Capitals
print('London' in Capitals)

# Is 'United Kingdom' in Capitals
print('United Kingdom' in Capitals)

# Is 'London' a value in Capitals
print('London'in Capitals.values())

# How many key/value pairs in the dictionary
print(len(Capitals))

## Dictionary methods

# get() method
print(Capitals.get('Madagascar'))

# No match
print(Capitals.get('USA'))

# No match with optional argument
print(Capitals.get('USA', 'No match!'))

# items() - Returns a list
print(Capitals.items())

# keys()
print(Capitals.keys())

# values()
print(Capitals.values())

# pop()
print(Capitals.pop('Palau','No match!'))

# pop() with optional argument
print(Capitals.pop('Germany','No match!'))

# update()
d1 = {"Peanut Butter":"Jam","Fish":"Chips"}
d2 = {"Toast":"Butter","Fish":"Peas"}

d1.update(d2)
print(d1)

# clear() method
Capitals.clear()
print(Capitals)

print("*****End of example*****\n")
