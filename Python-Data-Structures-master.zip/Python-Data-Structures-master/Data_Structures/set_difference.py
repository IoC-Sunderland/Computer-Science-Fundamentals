# initialize sets A and B
A = {1, 2, 3, 4, 5}
B = {4, 5, 6, 7, 8}

# use - operator on A to produce the Difference - 
# a set of elements that are only in A but not in B
# Output: {1, 2, 3}
print(A - B)