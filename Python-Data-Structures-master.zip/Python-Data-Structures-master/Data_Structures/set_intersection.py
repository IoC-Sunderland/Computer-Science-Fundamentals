# initialize sets A and B
A = {1, 2, 3, 4, 5}
B = {4, 5, 6, 7, 8}

# use & operator to produce an Intersection -
# a set of elements that are common in both sets
# Output: {4, 5}
print(A & B)