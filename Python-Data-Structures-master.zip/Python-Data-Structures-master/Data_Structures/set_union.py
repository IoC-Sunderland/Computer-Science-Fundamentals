# initialize sets A and B
A = {1, 2, 3, 4, 5}
B = {4, 5, 6, 7, 8}

# use | operator to produce a Union (a set of all elements from both sets)
# Output: {1, 2, 3, 4, 5, 6, 7, 8}
print(A | B)