# Sets 
x = set([1,2,3,4,5,5])

print("\n")
print("*****Example 7: Sets*****\n")
print("Current contents of 'x' Set: \n")
# Notice when you print the set only one 5 is present
print(x)
print("\n")

# Works on strings to
s = 'quux'

print(list(s))

print(set(s))

# Alternatively, define a set using curly braces
x = {'foo', 'bar', 'baz', 'foo', 'qux'}

print(x)

print({'foo'})

print(set('foo'))

# Define an empty set
x = set()

print(type(x))

# Not a set but a dictionary
x = {}
print(type(x))

# Lists and dicts are mutable and so can't be placed into a set
a = [1, 2, 3]

try:
    {a}
except TypeError as e:
    print(str(e))

d = {'a': 1, 'b': 2}

try:
    {d}
except TypeError as e:
    print(str(e))

x = {'foo', 'bar', 'baz'}

print(len(x))
    
print('bar' in x)

print('qux' in x)

# Combining sets
x1 = {'foo', 'bar', 'baz'}
x2 = {'baz', 'qux', 'quux'}

# union() method
print(x1.union(x2))

# | operator
print(x1 | x2)

print("*****End of example*****\n")
