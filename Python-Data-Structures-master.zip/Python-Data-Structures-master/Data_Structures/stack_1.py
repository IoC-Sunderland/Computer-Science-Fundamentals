# Create an empty list
myStack = []

# Call the .append() method to add an item to list
myStack.append('a')
myStack.append('b')
myStack.append('c')

print("\n")
print("*****Example 1: Using a list to create a Python stack*****\n")
print("Current contents of list: ")
print(myStack)
print("\n")

# Call the .pop() method to remove the last item added to list LIFO (Last In First Out)
print("Now we remove or 'pop' the following item: " + myStack.pop())
print("\n")

# And again
print("Now we remove or 'pop' the following item: " + myStack.pop())
print("\n")

#And again
print("Now we remove or 'pop' the following item: " + myStack.pop())
print("\n")

# Try calling .pop() when list is empty
try:
    myStack.pop()
except IndexError as e:
    print("Error when calling .pop().\n\nAssociated error message: " + str(e))

print("\n")
print("*****End of example*****\n")
