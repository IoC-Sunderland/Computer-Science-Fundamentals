# Using Python to implement a Stack
class Stack:
     def __init__(self):
         self.items = [] # Initialise an empty list

     def isEmpty(self):
         return self.items == [] # Is our Stack empty?, i.e., equal to an empty list

     def push(self, item):
         self.items.append(item) # Use append method to push an item onto Stack

     def pop(self):
         return self.items.pop() # Use pop method to remove item from top of Stack

     def peek(self):
         return self.items[len(self.items)-1] # Return item on top of Stack

     def size(self):
         return len(self.items) # Return the number of items in Stack

if __name__ == "__main__":
    s=Stack()
    print(s.isEmpty())
    s.push(4)
    s.push('dog')
    print(s.peek())
    s.push(True)
    print(s.size())
    print(s.isEmpty())
    s.push(8.4)
    print(s.pop())
    print(s.pop())
    print(s.size())