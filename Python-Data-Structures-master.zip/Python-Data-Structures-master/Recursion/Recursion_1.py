def callMe():
    callMe()

callMe()