def get_list_length(my_list):

    # Base case
    if my_list == []:
        return 0
    # Print call to help visualise the process
    print(my_list) 
    # Progress
    return 1 + get_list_length(my_list[1:])

print(get_list_length([1,2,3,4,5]))
